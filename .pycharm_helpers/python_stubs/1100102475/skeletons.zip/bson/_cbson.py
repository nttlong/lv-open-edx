# encoding: utf-8
# module bson._cbson
# from /usr/local/lib/python2.7/dist-packages/bson/_cbson.so
# by generator 1.145
# no doc
# no imports

# functions

def decode_all(*args, **kwargs): # real signature unknown
    """ convert binary data to a sequence of documents. """
    pass

def _bson_to_dict(*args, **kwargs): # real signature unknown
    """ convert a BSON string to a SON object. """
    pass

def _dict_to_bson(*args, **kwargs): # real signature unknown
    """ convert a dictionary to a string containing its BSON representation. """
    pass

# no classes
# variables with complex values

_C_API = None # (!) real value is ''


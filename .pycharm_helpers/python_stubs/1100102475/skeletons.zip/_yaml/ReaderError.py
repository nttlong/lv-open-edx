# encoding: utf-8
# module _yaml
# from /usr/lib/python2.7/dist-packages/_yaml.so
# by generator 1.145
# no doc

# imports
import yaml as yaml # /usr/lib/python2.7/dist-packages/yaml/__init__.pyc
import __builtin__ as __builtins__ # <module '__builtin__' (built-in)>
import yaml.error as __yaml_error
import yaml.events as __yaml_events
import yaml.nodes as __yaml_nodes
import yaml.tokens as __yaml_tokens


class ReaderError(__yaml_error.YAMLError):
    # no doc
    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    def __str__(self, *args, **kwargs): # real signature unknown
        pass



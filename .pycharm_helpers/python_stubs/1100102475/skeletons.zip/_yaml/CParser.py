# encoding: utf-8
# module _yaml
# from /usr/lib/python2.7/dist-packages/_yaml.so
# by generator 1.145
# no doc

# imports
import yaml as yaml # /usr/lib/python2.7/dist-packages/yaml/__init__.pyc
import __builtin__ as __builtins__ # <module '__builtin__' (built-in)>
import yaml.error as __yaml_error
import yaml.events as __yaml_events
import yaml.nodes as __yaml_nodes
import yaml.tokens as __yaml_tokens


from object import object

class CParser(object):
    # no doc
    def check_event(self, *args, **kwargs): # real signature unknown
        pass

    def check_node(self, *args, **kwargs): # real signature unknown
        pass

    def check_token(self, *args, **kwargs): # real signature unknown
        pass

    def dispose(self, *args, **kwargs): # real signature unknown
        pass

    def get_event(self, *args, **kwargs): # real signature unknown
        pass

    def get_node(self, *args, **kwargs): # real signature unknown
        pass

    def get_single_node(self, *args, **kwargs): # real signature unknown
        pass

    def get_token(self, *args, **kwargs): # real signature unknown
        pass

    def peek_event(self, *args, **kwargs): # real signature unknown
        pass

    def peek_token(self, *args, **kwargs): # real signature unknown
        pass

    def raw_parse(self, *args, **kwargs): # real signature unknown
        pass

    def raw_scan(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    @staticmethod # known case of __new__
    def __new__(S, *more): # real signature unknown; restored from __doc__
        """ T.__new__(S, ...) -> a new object with type S, a subtype of T """
        pass

    __pyx_vtable__ = None # (!) real value is ''



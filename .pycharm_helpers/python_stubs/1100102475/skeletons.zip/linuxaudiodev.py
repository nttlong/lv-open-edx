# encoding: utf-8
# module linuxaudiodev
# from /usr/lib/python2.7/lib-dynload/linuxaudiodev.x86_64-linux-gnu.so
# by generator 1.145
# no doc
# no imports

# Variables with simple values

AFMT_A_LAW = 2

AFMT_MU_LAW = 1

AFMT_S16_BE = 32
AFMT_S16_LE = 16
AFMT_S16_NE = 16

AFMT_S8 = 64

AFMT_U16_BE = 256
AFMT_U16_LE = 128

AFMT_U8 = 8

# functions

def open(*args, **kwargs): # real signature unknown
    pass

# classes

class error(Exception):
    # no doc
    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    __weakref__ = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """list of weak references to the object (if defined)"""




# encoding: utf-8
# module _multibytecodec
# from /usr/lib/python2.7/lib-dynload/_multibytecodec.x86_64-linux-gnu.so
# by generator 1.145
# no doc
# no imports

# functions

def __create_codec(*args, **kwargs): # real signature unknown
    pass

# classes

class MultibyteIncrementalDecoder(object):
    # no doc
    def decode(self, *args, **kwargs): # real signature unknown
        pass

    def reset(self, *args, **kwargs): # real signature unknown
        pass

    def __getattribute__(self, name): # real signature unknown; restored from __doc__
        """ x.__getattribute__('name') <==> x.name """
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    @staticmethod # known case of __new__
    def __new__(S, *more): # real signature unknown; restored from __doc__
        """ T.__new__(S, ...) -> a new object with type S, a subtype of T """
        pass

    errors = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """how to treat errors"""



class MultibyteIncrementalEncoder(object):
    # no doc
    def encode(self, *args, **kwargs): # real signature unknown
        pass

    def reset(self, *args, **kwargs): # real signature unknown
        pass

    def __getattribute__(self, name): # real signature unknown; restored from __doc__
        """ x.__getattribute__('name') <==> x.name """
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    @staticmethod # known case of __new__
    def __new__(S, *more): # real signature unknown; restored from __doc__
        """ T.__new__(S, ...) -> a new object with type S, a subtype of T """
        pass

    errors = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """how to treat errors"""



class MultibyteStreamReader(object):
    # no doc
    def read(self, *args, **kwargs): # real signature unknown
        pass

    def readline(self, *args, **kwargs): # real signature unknown
        pass

    def readlines(self, *args, **kwargs): # real signature unknown
        pass

    def reset(self, *args, **kwargs): # real signature unknown
        pass

    def __getattribute__(self, name): # real signature unknown; restored from __doc__
        """ x.__getattribute__('name') <==> x.name """
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    @staticmethod # known case of __new__
    def __new__(S, *more): # real signature unknown; restored from __doc__
        """ T.__new__(S, ...) -> a new object with type S, a subtype of T """
        pass

    errors = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """how to treat errors"""

    stream = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default



class MultibyteStreamWriter(object):
    # no doc
    def reset(self, *args, **kwargs): # real signature unknown
        pass

    def write(self, *args, **kwargs): # real signature unknown
        pass

    def writelines(self, *args, **kwargs): # real signature unknown
        pass

    def __getattribute__(self, name): # real signature unknown; restored from __doc__
        """ x.__getattribute__('name') <==> x.name """
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    @staticmethod # known case of __new__
    def __new__(S, *more): # real signature unknown; restored from __doc__
        """ T.__new__(S, ...) -> a new object with type S, a subtype of T """
        pass

    errors = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """how to treat errors"""

    stream = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default




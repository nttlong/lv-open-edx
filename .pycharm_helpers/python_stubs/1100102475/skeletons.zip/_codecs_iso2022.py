# encoding: utf-8
# module _codecs_iso2022
# from /usr/lib/python2.7/lib-dynload/_codecs_iso2022.x86_64-linux-gnu.so
# by generator 1.145
# no doc
# no imports

# functions

def getcodec(*args, **kwargs): # real signature unknown
    """  """
    pass

# no classes

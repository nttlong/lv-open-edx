
import lms
argo.db.set_connection_string("mysql://root:123456@172.16.7.63:3306/lv_lms")
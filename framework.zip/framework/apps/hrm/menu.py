# -*- coding: utf-8 -*-

menu_items=[
    dict(
        caption="Danh mục",
        items=[
            dict(
                caption="Tỉnh thành",
                page="categories/provinces",
                display_index=100
            ),
            dict(
                caption="Quận huyện",
                page="categories/districts",
                display_index=100
            )
        ]
    )
]



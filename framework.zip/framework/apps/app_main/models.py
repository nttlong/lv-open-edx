class Login:
    username=""
    language="en"
    password=""
    url_next=""
    def __init__(self):
        self.username=""
        self.password=""
        self.language="en"
        self.is_error=False
        self.error_message=""
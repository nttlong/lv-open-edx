class test:
    def get_app(self):
        import configuration
        return configuration.grt_app_info(__file__)
   